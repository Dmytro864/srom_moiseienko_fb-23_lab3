# === Тести ===
def print_test(title, func):
    start = time.perf_counter()
    result = func()
    end = time.perf_counter()
    print(f"{title}: {result}  (Час: {round((end - start) * 1e6)} мкс)")

a = GF2m.from_bin_str("0000000000000000000000000000000000000000000000000000000000000011")  
b = GF2m.from_bin_str("0000000000000000000000000000000000000000000000000000000000000101")  
c = GF2m.from_bin_str("0000000000000000000000000000000000000000000000000000000000000111")  
