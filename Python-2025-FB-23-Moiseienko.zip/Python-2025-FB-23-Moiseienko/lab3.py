import time

class GF2m:
    def __init__(self, value, m=163):
        self.m = m
        self.modulus = (1 << 163) | (1 << 7) | (1 << 6) | (1 << 3) | 1
        self.value = value & ((1 << m) - 1)

    def __str__(self):
        return self.to_bin_str()

    @staticmethod
    def zero(m=163):
        return GF2m(0, m)

    @staticmethod
    def one(m=163):
        return GF2m(1, m)

    def add(self, other):
        return GF2m(self.value ^ other.value, self.m)

    def mul(self, other):
        result = 0
        a, b = self.value, other.value
        for _ in range(self.m):
            if b & 1:
                result ^= a
            b >>= 1
            a <<= 1
            if a & (1 << self.m):
                a ^= self.modulus
        return GF2m(result, self.m)

    def square(self):
        return self.mul(self)

    def pow(self, exponent):
        result = GF2m.one(self.m)
        base = GF2m(self.value, self.m)
        while exponent > 0:
            if exponent & 1:
                result = result.mul(base)
            base = base.square()
            exponent >>= 1
        return result

    def inverse(self):
        r0, r1 = self.modulus, self.value
        s0, s1 = 1, 0
        while r1 != 0:
            q = r0.bit_length() - r1.bit_length()
            if q < 0:
                r0, r1 = r1, r0
                s0, s1 = s1, s0
                q = -q
            r0 ^= r1 << q
            s0 ^= s1 << q
        return GF2m(s1, self.m)

    def trace(self):
        result = GF2m(self.value, self.m)
        temp = GF2m(self.value, self.m)
        for _ in range(1, self.m):
            temp = temp.square()
            result = result.add(temp)
        return GF2m(result.value & 1, 1)

    def to_bin_str(self):
        return format(self.value, f'0{self.m}b')

    @staticmethod
    def from_bin_str(bin_str):
        return GF2m(int(bin_str, 2), len(bin_str))


# === Тести ===
def print_test(title, func):
    start = time.perf_counter()
    result = func()
    end = time.perf_counter()
    print(f"{title}: {result}  (Час: {round((end - start) * 1e6)} мкс)")

a = GF2m.from_bin_str("0000000000000000000000000000000000000000000000000000000000000011")  
b = GF2m.from_bin_str("0000000000000000000000000000000000000000000000000000000000000101")  
c = GF2m.from_bin_str("0000000000000000000000000000000000000000000000000000000000000111")  

print("Елементи:")
print("a =", a)
print("b =", b)
print("c =", c)

print_test("a + b", lambda: a.add(b))
print_test("a * b", lambda: a.mul(b))
print_test("a^2", lambda: a.square())
print_test("b^27", lambda: b.pow(27))
print_test("inverse(c)", lambda: c.inverse())
print_test("trace(a)", lambda: a.trace())

# Перевірка тотожностей
left = a.add(b).mul(c)
right = b.mul(c).add(c.mul(a))
print("\nПеревірка (a + b) * c == b * c + c * a :", left.value == right.value)

d = GF2m.from_bin_str("0000000000000000000000000000000000000000000000000000000000001000")
d_inv = d.inverse()
d_check = d.mul(d_inv)
print("d * d^-1 =", d_check)
print("Перевірка d * d^-1 == 1:", d_check.value == GF2m.one().value)

